package t;
import tictactoe.*;

import static org.junit.Assert.*;

import java.awt.Event;
import java.awt.event.ActionEvent;
import java.awt.event.MouseEvent;

import  org.junit.*;
import  org.mockito.Mockito;
public class testing {
		private static TicTacToeMain d;
		
		@Before
		public void pravljenjeigre() {
			d = new TicTacToeMain();
			d.setVisible(true);
		}
		@Test
		public void daliseVidePocetniGrafickiElementi(){
			assertEquals("Tic Tac Toe", d.getTitle());
		
		}
		@Test
		public void daliSePostavljaNaPravoMesto()
		{
			TicTacToeAI a=new TicTacToeAI();
			a.setBoardValue(1, 1, 1);
			assertEquals(1,a.getBoardValue(1, 1));
		}
		@Test
		public void daliCePostavitiAkoJeVanOpsega()
		{
			TicTacToeAI a=new TicTacToeAI();
			a.setBoardValue(-2, 5, 1);
			assertEquals(0,a.getBoardValue(4, 5));	
				
		}
		@Test
		public void DaLiRadiFUnkZaOcitavanjePobede(){
			TicTacToeAI a=new TicTacToeAI();
			a.setBoardValue(0, 0, 2);
			a.setBoardValue(0, 1, 0);
			a.setBoardValue(0, 2, 2);
			a.setBoardValue(1, 0, 0);
			a.setBoardValue(1, 1, 0);
			a.setBoardValue(1, 2, 0);
			a.setBoardValue(2, 0, 1);
			a.setBoardValue(2, 1, 1);
			a.setBoardValue(2, 2, 1);
			assertEquals(true,a.isWin(1));
			
			a.setBoardValue(0, 0, 2);
			a.setBoardValue(0, 1, 2);
			a.setBoardValue(0, 2, 1);
			a.setBoardValue(1, 0, 2);
			a.setBoardValue(1, 1, 1);
			a.setBoardValue(1, 2, 1);
			a.setBoardValue(2, 0, 1);
			a.setBoardValue(2, 1, 1);
			a.setBoardValue(2, 2, 2);
			assertEquals(true,a.isWin(1));
			
			a.setBoardValue(0, 0, 2);
			a.setBoardValue(0, 1, 1);
			a.setBoardValue(0, 2, 2);
			a.setBoardValue(1, 0, 1);
			a.setBoardValue(1, 1, 2);
			a.setBoardValue(1, 2, 1);
			a.setBoardValue(2, 0, 1);
			a.setBoardValue(2, 1, 2);
			a.setBoardValue(2, 2, 1);
			assertEquals(false,a.isWin(1));
		}
		
		@Test
		public void DInverse()
		{
			TicTacToeAI a=new TicTacToeAI();
			assertEquals(2,a.inverse(1));
			assertEquals(1,a.inverse(2));
		}
		
		@Test
		public void DalijesetLabela()
		{   
			assertEquals("Click 'Play' To Start",d.statusLabel.getText());
		}
		@Test
		public void proveraSetButtEnabled()
		{
              assertEquals(false, d.buttons[0][2].isEnabled());
              assertEquals(false, d.buttons[1][1].isEnabled());
              assertEquals(false, d.buttons[2][0].isEnabled());
              assertEquals(false, d.buttons[0][1].isEnabled());
              assertEquals(false, d.buttons[0][0].isEnabled());
              assertEquals(false, d.buttons[1][0].isEnabled());
              assertEquals(false, d.buttons[1][2].isEnabled());
              assertEquals(false, d.buttons[2][1].isEnabled());
              assertEquals(false, d.buttons[2][2].isEnabled());
		}
	
		
		@Test
		public void testirajplay(){
			d.play();
			assertEquals("Your Turn",d.statusLabel.getText());
			assertEquals(true,d.isPlay);
			assertEquals(TicTacToeAI.ONE,d.human);
			assertEquals(TicTacToeAI.TWO,d.computer);
			
		}
		@Test 
		public void ProveriClick()
		{   d.play();
			d.click(1, 1);
			assertEquals(1,d.game.getBoardValue(1, 1));
			d.click(2, 2);
			assertEquals(1,d.game.getBoardValue(2,2));
			
		}
		
		@Test public void IspisPobede(){
			d.play();
			d.click(0, 0);
			d.click(2, 2);
			d.click(2,1);
			d.click(1,0);
			assertEquals("Sorry, You Lose!",d.statusLabel.getText());
			
			}
		@Test 
		public void IspisPobeda(){
			d.play();
			d.click(1, 1);
			d.click(2, 2);
			d.click(0, 2);
			d.click(2,0);
			assertEquals("Congratulations, You've Won!",d.statusLabel.getText());
		
		}
		@Test 
		public void IspisNereseno(){
			d.play();
			d.click(1, 1);
            d.click(1, 0);
            d.click(0, 2);
            d.click(2, 2);
            d.click(2, 1);
            assertEquals("Draw, Click 'Play' For Rematch!",d.statusLabel.getText());
		}
		@Test
		public void TAction()
		{    d.play();
		ActionEvent as=new ActionEvent(d.buttons[1][1], 0, null);
		// as.setSource(d.buttons[1][1]);
			 for(int i=0;i<3;i++)
				    for(int j=0;j<3;j++)
				     if(as.getSource()==d.buttons[i][j])
				      d.click(i,j);
			//d.click(as.getSource().getClass()., j);
			assertEquals(1,d.game.getBoardValue(1, 1));
			
			
		}
		@Test
		public void mockito1()
		{
			TicTacToeAI a=Mockito.mock(TicTacToeAI.class);
			
			Mockito.when(a.inverse(1)).thenReturn(2);
			assertEquals(2,a.inverse(1));
			
			
		}

		@Test
		public void mockito2()
		{
			TicTacToeAI a=Mockito.mock(TicTacToeAI.class);
			a.setBoardValue(1, 1, 1);
			Mockito.when(a.getBoardValue(1,1)).thenReturn(1);
			assertEquals(1,a.getBoardValue(1, 1));
			
		}
		@Test
		public void mockito3()
		{     
		TicTacToeAI a=Mockito.mock(TicTacToeAI.class);
		a.setBoardValue(0, 0, 2);
		a.setBoardValue(0, 1, 0);
		a.setBoardValue(0, 2, 2);
		a.setBoardValue(1, 0, 0);
		a.setBoardValue(1, 1, 0);
		a.setBoardValue(1, 2, 0);
		a.setBoardValue(2, 0, 1);
		a.setBoardValue(2, 1, 1);
		a.setBoardValue(2, 2, 1);
		
			Mockito.when(a.isWin(1)).thenReturn(true);
			assertEquals(true,a.isWin(1));
		}
		@After
		public void gasenjeigre(){
			d.setVisible(false);
		}
}
